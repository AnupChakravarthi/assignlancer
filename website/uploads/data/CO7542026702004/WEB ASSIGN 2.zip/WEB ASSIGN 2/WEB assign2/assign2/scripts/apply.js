/* Author : SRAMIKA JANGITI
 * Target : HTML AND JOBS.HTML
 * Purpose: TO STORE THE DETAILS AND DISPLAY THE ERRORS
 * Created: 24/04/2019
 * Updated: 26/04/2019
 */

 "use strict";
 function validate(){
 	 var error="";
 	 var result=true;
   var date = document.getElementById("dob").value;
   var bDay = new Date(date);
   // age calculation
   var err1 = calculate_currentAge(bDay);
   if(err1!=""){
      error+= err1;
      result=false;
   }
   var pCode = document.getElementById("pos").value;
   var state = document.getElementById("state").value;
   // check for state and postcode match
   var err2 = statepCodeValidator(state,pCode);
   if(err2!=""){
      error+= err2;
      result=false;
   }
   // check for other skills
   var err3 = checkForOtherSkills();
   if(err3!=""){
     error+=err3;
     result=false;
   }
   //display error messages in web page
   if(error!=""){
     var displayAllError = document.getElementById("error");
     displayAllError.innerHTML = error;
   }
   else {
     //store data on successful validation
     storeData();
   }
   return result;
 }


 function calculate_currentAge(bDay) {
     var now = new Date();
     var msg ="";
     var currentAge = now.getFullYear() - bDay.getFullYear();
     if(now.getMonth() <= bDay.getMonth() && now.getDate() > bDay.getDate()){
       currentAge--;
     }
     if(currentAge<15 || currentAge>80){
        msg = "Age do not fall under specified range <br/>";
     }
     return msg;
 }


 function statepCodeValidator(state,pCode){
   var errMsg = "";
    var pCodeValidator = Math.floor(pCode / 1000);
    switch (state) {
        case "VIC":
            if (!(pCodeValidator == 3 || pCodeValidator == 8)) {
                errMsg += "Postcode for VIC should begin with 3 or 8<br>";
            }
            break;
        case "NSW":
            if (!(pCodeValidator == 1 || pCodeValidator == 2)) {
                errMsg += "Postcode for NSW should begin with 1 or 2<br>";
            }
            break;
        case "QLD":
            if (!(pCodeValidator == 4 || pCodeValidator == 9)) {
                errMsg += "Postcode for QLD should begin with 4 or 9<br>";
            }
            break;
        case "NT":
            if (!(pCodeValidator == 0)) {
                errMsg += "Postcode for NT should begin 0<br>";
            }
            break;
        case "WA":
            if (!(pCodeValidator == 6)) {
                errMsg += "Postcode for WA should begin 6<br>";
            }
            break;
        case "SA":
            if (!(pCodeValidator == 5)) {
                errMsg += "Postcode for SA should begin 5<br>";
            }
            break;
        case "TAS":
            if (!(pCodeValidator == 7)) {
                errMsg += "Postcode for TAS should begin 7<br>";
            }
            break;
        case "ACT":
            if (!(pCodeValidator == 0)) {
                errMsg += "Postcode for ACT should begin 0<br>";
            }
            break;
        default:
            errMsg += "Not a valid state<br>";
    }
    return errMsg;

}


function checkForOtherSkills(){
  var allSkillsArray = document.getElementsByName("skills[]");
  var otherskills = document.getElementById("otherskills").value;
  var error = "";
  for(var i =0;i<allSkillsArray.length;i++) {
      if(allSkillsArray[i].checked){
        if(allSkillsArray[i].value=="Other skills" && otherskills.length==0){
          error = "Please fill otherskills section<br/>";
        }
      }
  }

  return error;
}
function getReferenceNumber(){
  alert(this.id);
  var referenceFromJobs = this.id;
  localStorage.refNum = referenceFromJobs;
}

function getSkills(){
  var skills = document.getElementsByName('skills[]');
  var allSkills = [];
  for(var i=0;i<skills.length;i++) {
    if(skills[i].checked){
      allSkills.push(skills[i].value);
    }
  }
  return JSON.stringify(allSkills);
}

function storeData() {
  var firstName = document.getElementById("firstname").value;
  var lastName = document.getElementById("lastname").value;
  var date = document.getElementById("dob").value;
  var address = document.getElementById("address").value;
  var town = document.getElementById("town").value;
  var state = document.getElementById("state").value;
  var pCode = document.getElementById("pos").value;
  var email = document.getElementById("mail").value;
  var phone = document.getElementById("phoneno").value;
  var otherSkills = document.getElementById("otherskills").value;
  var female = document.getElementById("female");
  var male = document.getElementById("male");
  sessionStorage.firstName = firstName;
  sessionStorage.lastName = lastName;
  sessionStorage.dob = date;
  sessionStorage.address = address;
  sessionStorage.town = town;
  sessionStorage.state = state;
  sessionStorage.pCode = pCode;
  sessionStorage.email = email;
  sessionStorage.phone = phone;
  sessionStorage.otherSkills = otherSkills;
  sessionStorage.skills = getSkills();
  if(male.checked){
      sessionStorage.gender = male.value;
  }
  else{
      sessionStorage.gender = female.value;
  }
}
function prefillForm(){
  if(sessionStorage.firstName != undefined ){

    document.getElementById("firstname").value = sessionStorage.firstName;
    document.getElementById("lastname").value = sessionStorage.lastName;
    document.getElementById("dob").value = sessionStorage.dob;

    document.getElementById("address").value = sessionStorage.address;
    document.getElementById("town").value = sessionStorage.town;
    document.getElementById("state").value = sessionStorage.state;
    document.getElementById("pos").value = sessionStorage.pCode;
    document.getElementById("mail").value = sessionStorage.email;
    document.getElementById("phoneno").value = sessionStorage.phone;
    document.getElementById("otherskills").value = sessionStorage.otherSkills;

    var gender = document.getElementsByName("gender");
    if(sessionStorage.gender != undefined && sessionStorage.gender != "" && sessionStorage.gender != null){
      for(var i=0;i<gender.length;i++) {
          if(gender[i].value == sessionStorage.gender) {
              gender[i].checked = true;
        }
      }
    }
    var skills = JSON.parse(sessionStorage.skills);
    var skillsInputs = document.getElementsByName("skills[]");
    if(sessionStorage.skills != undefined && sessionStorage.skills != "" && sessionStorage.skills != null){
      for (var i = 0; i < skills.length; i++) {
        for (var j = 0; j < skillsInputs.length; j++) {
          if(skills[i]==skillsInputs[j].value){
            skillsInputs[j].checked = true;
          }
        }
      }
    }
}
}



 function init(){
   var getReferenceToForm = document.getElementsByClassName("jobreference");
   // get reference number from jobs page
   if (getReferenceToForm){
     for(var i =0;i<getReferenceToForm.length;i++) {
         getReferenceToForm[i].onclick = getReferenceNumber;
     }
   }

 	var form = document.getElementById("form");   // get ref to the HTML element
  if(form){
      // display reference number in form page
      document.getElementById("refnum").value = localStorage.refNum;
      // prefill form
      prefillForm();
      form.onsubmit = validate;
  }

 }
 window.onload = init;

