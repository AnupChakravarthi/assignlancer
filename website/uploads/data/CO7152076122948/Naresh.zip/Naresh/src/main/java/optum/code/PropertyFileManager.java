package optum.code;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class PropertyFileManager {

	public static final String PROPERTYFILEPATH=System.getProperty("user.dir")+"\\files\\sample.properties";
	public void writePropertyFile(){
		Properties prop = new Properties();
		OutputStream output = null;
		try {
			output = new FileOutputStream(PROPERTYFILEPATH);
			// set the properties value
			prop.setProperty("database", "jdbc:sqlserver://localhost:1433/mytestSQL");
			prop.setProperty("dbuser", "naresh");
			prop.setProperty("dbpassword", "password");
			// save properties to project root folder
			prop.store(output, null);

		} catch (IOException io) {
			io.printStackTrace();
		} finally {
			if (output != null) {
				try {
					output.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}
	}
	
	public void readPropertyFile(){
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream(PROPERTYFILEPATH);
			// load a properties file
			prop.load(input);
			// get the property value and print it out
			System.out.println("database: "+prop.getProperty("database"));
			System.out.println("dbuser: "+prop.getProperty("dbuser"));
			System.out.println("dbpassword: "+prop.getProperty("dbpassword"));

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
		
	public static void main(String[] args) {
	PropertyFileManager propManager=new PropertyFileManager();
    /* Write a property File */
	   propManager.writePropertyFile();
    /* Read a property File */
	   propManager.readPropertyFile();
	}

}
