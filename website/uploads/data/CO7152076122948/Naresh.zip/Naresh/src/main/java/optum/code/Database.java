package optum.code;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
 public static final String JDBC_DRIVER = "com.microsoft.jdbc.sqlserver.SQLServerDriver";  
 public static final String DB_URL = "jdbc:sqlserver://localhost:1433/mytestSQL";
 public static final String USER = "username";
 public static final String PASS = "password";
	
 public void addRecords(int id, String firstName, String lastName, int age){
	 Connection conn = null;
	 Statement stmt = null;
	 try{
	      Class.forName(JDBC_DRIVER);
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      stmt = conn.createStatement();
	      String sql = "INSERT INTO Registration VALUES ("+id+", '"+firstName+"', '"+lastName+"', "+age+")";
	      stmt.executeUpdate(sql);

	   } 
	   catch(Exception e){   e.printStackTrace(); }
	   finally{
		   try{
	         if(stmt!=null) {  conn.close(); }
	        } 
		   catch(SQLException se){ se.printStackTrace(); }// do nothing
	      try{
	         if(conn!=null) { conn.close(); }
	      }
	      catch(SQLException se){  se.printStackTrace();  }
	   }
 }

 public void viewRecord(int id){
	 Connection conn = null;
	 Statement stmt = null;
	 try{
	      Class.forName(JDBC_DRIVER);
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      stmt = conn.createStatement();
	      String sql = "SELECT * FROM Registration WHERE id="+id+";";
	      ResultSet rs = stmt.executeQuery(sql);
	      while(rs.next()){
	          int age = rs.getInt("age");
	          String firstName = rs.getString("firstName");
	          String lastName = rs.getString("lastName");
	          System.out.println("ID: " + id);
	          System.out.println("FirstName: " + firstName);
	          System.out.println("LastName: " + lastName);
	          System.out.println("Age: " + age);
	       }
	       rs.close();

	   } 
	   catch(Exception e){   e.printStackTrace(); }
	   finally{
		   try{
	         if(stmt!=null) {  conn.close(); }
	        } 
		   catch(SQLException se){ se.printStackTrace(); }// do nothing
	      try{
	         if(conn!=null) { conn.close(); }
	      }
	      catch(SQLException se){  se.printStackTrace();  }
	   }
 }
 
 public void updateRecords(int id, String key, String value){
	 Connection conn = null;
	 Statement stmt = null;
	 try{
	      Class.forName(JDBC_DRIVER);
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      stmt = conn.createStatement();
	      String sql = "UPDATE Registration SET"+key+" = "+value+" WHERE id = "+id+";";
	      stmt.executeUpdate(sql);

	   } 
	   catch(Exception e){   e.printStackTrace(); }
	   finally{
		   try{
	         if(stmt!=null) {  conn.close(); }
	        } 
		   catch(SQLException se){ se.printStackTrace(); }// do nothing
	      try{
	         if(conn!=null) { conn.close(); }
	      }
	      catch(SQLException se){  se.printStackTrace();  }
	   }
 }
 
 public void deleteRecord(int id){
	 Connection conn = null;
	 Statement stmt = null;
	 try{
	      Class.forName(JDBC_DRIVER);
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      stmt = conn.createStatement();
	      String sql = "DELETE FROM Registration WHERE id = "+id+";";
	      stmt.executeUpdate(sql);

	   } 
	   catch(Exception e){   e.printStackTrace(); }
	   finally{
		   try{
	         if(stmt!=null) {  conn.close(); }
	        } 
		   catch(SQLException se){ se.printStackTrace(); }// do nothing
	      try{
	         if(conn!=null) { conn.close(); }
	      }
	      catch(SQLException se){  se.printStackTrace();  }
	   }
 }
 
 public static void main(String[] args) {
	 /* Data : */
	 int id=001;
	 String firstName="Naresh Kumar";
	 String lastName="Yayavaram"; 
	 int age=16;
	 
	 Database database=new Database();
	 /* INSERT RECORDS : */
	 database.addRecords(id, firstName, lastName, age);
	 /* SELECT RECORDS */
	 database.viewRecord(id);
	 /* UPDATE RECORDS */
	 database.updateRecords(id, "age", "18");
	 database.viewRecord(id);
	 /* DELETE RECORDS */
	 database.deleteRecord(id);
 }

}
