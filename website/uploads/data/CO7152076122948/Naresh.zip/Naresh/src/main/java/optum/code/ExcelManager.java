package optum.code;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

public class ExcelManager {

	public static final String EXCELFILEPATH=System.getProperty("user.dir")+"\\files\\sample.xlsx";
	
	public void writeExcel(){
		 XSSFWorkbook workbook = new XSSFWorkbook();
	        XSSFSheet sheet = workbook.createSheet("Datatypes in Java");
	        Object[][] datatypes = {
	                {"Datatype", "Type", "Size(in bytes)"},
	                {"int", "Primitive", 2},
	                {"float", "Primitive", 4},
	                {"double", "Primitive", 8},
	                {"char", "Primitive", 1},
	                {"String", "Non-Primitive", "No fixed size"}
	        };

	        int rowNum = 0;
	        
	        for (Object[] datatype : datatypes) {
	            Row row = sheet.createRow(rowNum++);
	            int colNum = 0;
	            for (Object field : datatype) {
	                Cell cell = row.createCell(colNum++);
	                if (field instanceof String) {  cell.setCellValue((String) field); } 
	                else if (field instanceof Integer) {  cell.setCellValue((Integer) field); }
	            }
	        }

	        try {
	            FileOutputStream outputStream = new FileOutputStream(EXCELFILEPATH);
	            workbook.write(outputStream);
	            workbook.close();
	        } catch (FileNotFoundException e) {  e.printStackTrace();  } 
	          catch (IOException e) { e.printStackTrace();  }

	}
	
	public void readExcel(){
		 try {

	            FileInputStream excelFile = new FileInputStream(new File(EXCELFILEPATH));
	            Workbook workbook = new XSSFWorkbook(excelFile);
	            Sheet datatypeSheet = workbook.getSheetAt(0);
	            Iterator<Row> iterator = datatypeSheet.iterator();

	            while (iterator.hasNext()) {

	                Row currentRow = iterator.next();
	                Iterator<Cell> cellIterator = currentRow.iterator();

	                while (cellIterator.hasNext()) {

	                    Cell currentCell = cellIterator.next();
	                     if (currentCell.getCellTypeEnum() == CellType.STRING) {
	                       System.out.print(currentCell.getStringCellValue() + "--");
	                    } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
	                       System.out.print(currentCell.getNumericCellValue() + "--");
	                   }

	                }
	                System.out.println();

	            }
	            workbook.close();
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	}
	
	public static void main(String args[]){
		ExcelManager  excelManager=new ExcelManager();
		/* Write Data into Excel */
		    excelManager.writeExcel();
		/* Read Data from Excel */
		    excelManager.readExcel();
	}
}
