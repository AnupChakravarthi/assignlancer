package optum.code;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;


public class XMLFileManager {

	public static final String XMLFILEPATH=System.getProperty("user.dir")+"\\files\\sample.xml";
	
	public void writeXMLFile(){
		try {
	         DocumentBuilderFactory dbFactory =DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.newDocument();
	         
	         // root element
	         Element rootElement = doc.createElement("xmlproperties");
	         doc.appendChild(rootElement);

	         // setting attribute to element
	         Attr attr = doc.createAttribute("database");
	         attr.setValue("sqlserver");
	         rootElement.setAttributeNode(attr);

	         // property element
	         Element property01 = doc.createElement("property");
	         Attr attrType01 = doc.createAttribute("name");
	         attrType01.setValue("database");
	         property01.setAttributeNode(attrType01);
	         property01.appendChild(doc.createTextNode("jdbc:sqlserver://localhost:1433/mytestSQL"));
	         rootElement.appendChild(property01);

	         Element property02 = doc.createElement("property");
	         Attr attrType02 = doc.createAttribute("name");
	         attrType02.setValue("dbuser");
	         property02.setAttributeNode(attrType02);
	         property02.appendChild(doc.createTextNode("naresh"));
	         rootElement.appendChild(property02);
	         
	         Element property03 = doc.createElement("property");
	         Attr attrType03 = doc.createAttribute("name");
	         attrType03.setValue("dbpassword");
	         property03.setAttributeNode(attrType03);
	         property03.appendChild(doc.createTextNode("password"));
	         rootElement.appendChild(property03);

	         // write the content into xml file
	         TransformerFactory transformerFactory = TransformerFactory.newInstance();
	         Transformer transformer = transformerFactory.newTransformer();
	         DOMSource source = new DOMSource(doc);
	         StreamResult result = new StreamResult(new File(XMLFILEPATH));
	         transformer.transform(source, result);
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	}
	
	public void readXMLFile(){
		try {
			File fXmlFile = new File(XMLFILEPATH);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("property");
			for(int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println(eElement.getAttribute("name")+":"+ eElement.getTextContent());
				}
			}
		    } catch (Exception e) {
			e.printStackTrace();
		    }
	}
	
	public static void main(String args[]){
		XMLFileManager xmlFileManager=new XMLFileManager();
		/* Write an XML File */
		xmlFileManager.writeXMLFile();
		/* Read an XML File */
		xmlFileManager.readXMLFile();
	}
}
