CREATE DATABASE mytestSQL;
USE mytestSQL;
CREATE TABLE Registration(
   id   INT  NOT NULL,
   firstName VARCHAR (30),
   lastName  VARCHAR (30),
   age INT,      
   PRIMARY KEY (ID)
);